Minecraft 3D Textures

This Resource Pack is for a Prison Server called "Wicked Prison".
It contains couple Textures combined.

- KeyVaults
- Bombs
- Keys

*You can see all Textures in this Pack, when you go one Folder back and look in the Folder with the Name "Wicked"*

Make sure you use Optifine 1.12.2 !

The Pack is tested on Version 12.2.2
Created with BlockBench 3.8.4+
Credits to Yanneckh.
