Minecraft 3D Textures

This Resource Pack is for a Prison Server called "Wicked Prison".
It contains a 3D Custom Texture for Keys.

Keys.png = Texture from all Key's. (Legendary, Rare, Mine and Corrupted)
KeysInInv.png = Textures from Mine, Rare and Legendary Key in KeyVault

Make sure you use Optifine 1.12.2 !

The Pack is tested on Version 12.2.2
Created with BlockBench 3.8.4+
Credits to Yanneckh.
