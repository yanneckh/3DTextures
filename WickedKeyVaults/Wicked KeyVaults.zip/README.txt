Minecraft 3D Textures

This Resource Pack is for a Prison Server called "Wicked Prison".
It contains a 3D Custom Texture for Key Vaults.

SmallMedKv.png = Texture for Small and Medium Key Vaults
LargeHugeKv.png = Texture for Large and Huge Key Vaults
GigaBigKv.png = Texture for Gigantic and Big Key Vaults

Make sure you use Optifine 1.12.2 !

The Pack is tested on Version 12.2.2
Created with BlockBench 3.8.4+
Credits to Yanneckh.
